$(document).ready(function () {



  $("#about-btn").click(function (event) {
    alert("You clicked the button using JQuery!");
  });

});